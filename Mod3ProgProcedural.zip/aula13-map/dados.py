produtos = [
    {'nome': 'p1', 'preco': 13},
    {'nome': 'p2', 'preco': 55.55},
    {'nome': 'p3', 'preco': 5.59},
    {'nome': 'p4', 'preco': 22},
    {'nome': 'p5', 'preco': 81.23},
    {'nome': 'p6', 'preco': 5.7},
    {'nome': 'p7', 'preco': 10.90},
    {'nome': 'p8', 'preco': 89.82},
    {'nome': 'p9', 'preco': 12},
    {'nome': 'p10', 'preco': 2.90},
]

pessoas = [
    {'nome': 'Luiz', 'idade': 12},
    {'nome': 'Eduarda', 'idade': 43},
    {'nome': 'Joana', 'idade': 65},
    {'nome': 'Lucas', 'idade': 14},
    {'nome': 'Felipe', 'idade': 17},
    {'nome': 'Maria', 'idade': 19},
    {'nome': 'Júlia', 'idade': 25},
    {'nome': 'Diniz', 'idade': 32},
    {'nome': 'Max', 'idade': 23},
    {'nome': 'Eduardo', 'idade': 59},
]

lista = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
