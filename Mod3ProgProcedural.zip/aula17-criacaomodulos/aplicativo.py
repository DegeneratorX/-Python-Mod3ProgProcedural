import calculos

print(calculos.PI)

lista = [2, 4]

print(calculos.multiplica(lista))
