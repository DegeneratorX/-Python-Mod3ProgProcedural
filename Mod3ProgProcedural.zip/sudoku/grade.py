def inserir_entrada_tabuleiro(entrada_convertido_indices, tabuleiro):
    for j in range(9):
        for i in range(9):
            if j == entrada_convertido_indices[1] and i == entrada_convertido_indices[0]:
                tabuleiro[j][i] = entrada_convertido_indices[2]
    return tabuleiro


def deletar_entrada_tabuleiro(entrada_convertido_indices, tabuleiro, matriz_pistas_resposta_com_indices):
    #print("OLHA AQUI: ", entrada_convertido_indices[0])
    for j in range(9):
        for i in range(9):
            if j == entrada_convertido_indices[1] and i == entrada_convertido_indices[0]:
                if tabuleiro[j][i] == 0:
                    print("Impossível deletar um espaço vazio!")
                    return tabuleiro
                else:
                    for k in range(len(matriz_pistas_resposta_com_indices)):
                        if tabuleiro[j][i] == matriz_pistas_resposta_com_indices[k][2]:
                            print(f"O valor {matriz_pistas_resposta_com_indices[k][2]} não pode ser deletado, pois é uma pista!")
                            return tabuleiro
                    print(f"Valor {tabuleiro[j][i]} deletado com sucesso!")
                    tabuleiro[j][i] = 0
    return tabuleiro
