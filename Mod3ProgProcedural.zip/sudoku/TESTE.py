
nome = "Victor"

if "V" in nome:
    print('CAGUEI')
