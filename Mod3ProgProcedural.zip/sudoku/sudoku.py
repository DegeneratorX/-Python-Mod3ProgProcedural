import numbers
import sys
import re
import grade
from checagem_repeticoes_pista import quadrantes, linhas_colunas
import checagem_repeticoes_tabuleiro
from reposicao_valores_pista import pista_coord_para_indices, entrada_coord_para_indices
import time
import desenho_grade



print("#"*40)
print("#"*16, "SUDOKU", "#"*16)
print("#"*40)


while True:

    print()
    modo_jogo_str = input("Selecione o tipo de jogo que você quer executar. Digite 0 para modo Iterativo, 1 para modo Batch: ")

    try:
        modo_jogo = int(modo_jogo_str)
        if modo_jogo > 1 or modo_jogo < 0:
            print("Erro: você digitou números fora do pedido!")
        else:
            break

    except ValueError:
        print("Erro: Você não digitou números válidos.")
        continue

modo_jogo = int(modo_jogo_str)

horizontal = "ABCDEFGHI"
vertical = "123456789"


if modo_jogo == 0:
    # f = sys.argv[1]  # indice 0 = sudoku.py. indice 1 = arq_01_cfg.txt ... etc.
    # Recebe qualquer argumento que for compilado no terminal junto com o arquivo sudoku.py
    # Os índices acessam os respectivos argumentos em ordem nos quais foram passados.

    with open('arq_01_cfg.txt', 'r') as file:  # Abro o arquivo cfg
        dados_arquivo = file.read()  # passo os dados lidos para uma variável
        #print(dados_arquivo)
        file.seek(0, 0)  # Ao ler, volto o cursor pra estaca 0

        if file.read() == "":  # Leio o arquivo novamente pra checar se ele está vazio.
            print(f"Erro! Arquivo vazio.")
            exit(1)
        file.seek(0, 0)  # Volto o cursor pro 0.
        linhas = file.read().split('\n')  # Separo cada \n em novas listas!
        #print(linhas)
        matriz_pistas = []
        print()

        for linha in linhas:  # Percorrendo as listas.
            linha_dividida = re.split(',|:', linha)  # E separo novamente os valores dessa lista em outras listas, tirando , e : para criar novas.
            #print(linha_dividida)
            numero = False  # VARIÁVEIS DE CONTROLE
            letra = True
            matriz_pistas.append(linha_dividida)  # Adiciono a uma lista vazia para criar uma matriz com os valores.
            for coord in linha_dividida:  # Percorro cada valor (coordenadas) de cada linha

                #print(coord)
                if (coord not in horizontal and coord not in vertical) or len(linha_dividida) != 3:  # Se as coordenadas não estiverem de acordo com o que foi pedido, sai do programa.
                    print("Erro: arquivo com valores inválidos!")
                    exit(1)
                if not coord.isdigit() and letra:  # Verifica se é uma letra e prepara para receber um número no próximo valor lido
                    numero = True
                    letra = False
                    pass
                elif coord.isdigit() and numero:  # Verifica se é um número
                    pass
                else:
                    print("Erro: arquivo com coordenadas inválidas ou trocadas!")  # Se algo tiver trocado, mesmo que dentro do escopo de A a I ou 1 a 9, cai aqui.
                    exit(1)

        if len(matriz_pistas) > 80 or len(matriz_pistas) < 1:
            print("Erro: arquivo com mais de 80 pistas! (Ou nenhuma)")
            exit(1)

        coord_repetidas = []
        for item in matriz_pistas:
            hor, vert, valor = item
            concatenacao = hor+vert
            coord_repetidas.append(concatenacao)

        if len(coord_repetidas) != len(set(coord_repetidas)):
            print("Erro: pista fornecendo valores diferentes pra uma mesma coordenada! Encerrando...")
            exit(1)

        quad = []  # Quadrante vazio
        horizontal_vazio = [[],[],[],[],[],[],[],[],[]]  # Linhas vazias
        vertical_vazio = [[],[],[],[],[],[],[],[],[]]  # Colunas vazias
        quadrantes(quad, matriz_pistas)  # Verifica se há repetições de valores em quadrantes
        linhas_colunas(horizontal_vazio, vertical_vazio, matriz_pistas)  # Verifica se há repetições de valores em linhas e colunas

        matriz_pistas_repostas_com_indices = pista_coord_para_indices(matriz_pistas)  # Substitui, das pistas, A...I e 1...9 por índices de 0 a 8 para o interpretador ler e trabalhar com listas.

        tabuleiro = [
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
        ]
        #print(matriz_pistas_repostas_com_indices)
        for linha in matriz_pistas_repostas_com_indices:  # Após validar a pista, começo a colocar os valores da pista fornecida em uma matriz vazia que corresponde ao tabuleiro.
            #print(linha)
            for i in range(9):
                for j in range(9):
                    if linha[0] == i and linha[1] == j:
                        tabuleiro[j][i] = linha[2]
        #for i in tabuleiro:
        #    print(i)

    print("Arquivo com pistas válido! Vamos começar a jogar...")
    print("\n")
    time.sleep(1)
    #print(matriz_pistas)

    ############ JOGO MODO INTERATIVO COMEÇA AQUI! ############

    while True:

        desenho_grade.desenho_grade(tabuleiro)
        # for linhas in tabuleiro:
        #     print(linhas)
        print()
        repetir_while = False
        deletar_coordenada = False

        print("Informe a linha de A a I, coluna de 1 a 9 e o valor, no formato COLUNA,LINHA:VALOR")
        print("Para deletar uma jogada, digite D como parâmetro inicial, depois coloque a coluna e linha. Exemplo: DA,3 deletará a coordenada [D,3]")
        entrada_bruta = input("COORDENADAS: ").replace(" ", "")  # Remoção e tolerância dos espaços
        #print(entrada_bruta)
        if len(entrada_bruta) < 4:
            print("Parâmetros inválidos!")
            print()
            continue

        if not entrada_bruta[1] == ',' or not entrada_bruta[3] == ':':  # Verifica se obedece padrões de vírgula e dois pontos.
            if (entrada_bruta[0] == 'D' or entrada_bruta[0] == 'd') and entrada_bruta[2] == ',':
                deletar_coordenada = True

            if deletar_coordenada == False:
                print("Parâmetros inválidos!")
                print()
                continue

        entrada_lista = re.split(",|:", entrada_bruta)  # Conversão direta da entrada em lista
        #print(entrada_lista)

        if deletar_coordenada == False:
            if entrada_lista[0] not in horizontal+"abcdefghi" or entrada_lista[1] not in vertical:
                print("Coordenadas inválidas! As coordenadas devem ser de A a I e 1 a 9.")  # Checagem para saber se as coordenadas foram de A a I ou 1 a 9.
                print()
                continue

            if entrada_lista[2] not in vertical:
                print("Valor inválido! O valor passado deve ser de 1 a 9.")  # Checagem para saber se o valor atribuido a coordenada é de 1 a 9
                print()
                continue

        if deletar_coordenada:
            entrada_lista[0].capitalize()  # uppercase apenas na primeira letra, o D, para também aceitar d pequeno.
            entrada_lista[0] = entrada_lista[0][1:]  # Splito a string e removo o D apenas pra trabalhar com as coordenadas
            entrada_convertido_indices = entrada_coord_para_indices(entrada_lista)  # Converto os primeiros índices
            #print(matriz_pistas_repostas_com_indices)
            tabuleiro = grade.deletar_entrada_tabuleiro(entrada_convertido_indices, tabuleiro, matriz_pistas_repostas_com_indices)  # Deleto da grade o valor atendendo as condições do trab.
            continue

        entrada_convertido_indices = entrada_coord_para_indices(entrada_lista)

        for i in matriz_pistas_repostas_com_indices:
            if entrada_convertido_indices[:2] == i[:2]:  # checagem pra saber se a coordenada passada já tem uma pista.
                print("Jogada inválida: A coordenada já está preenchida com uma pista!")
                print()
                repetir_while = True
                break
        if repetir_while:
            continue

        if checagem_repeticoes_tabuleiro.repeticoes_quadrante_entrada(entrada_convertido_indices, tabuleiro):  # Checagem pra ver se o quadrante já tem um valor igual.
            continue

        if checagem_repeticoes_tabuleiro.repeticoes_linha_coluna(entrada_convertido_indices, tabuleiro):
            continue

        tabuleiro = grade.inserir_entrada_tabuleiro(entrada_convertido_indices, tabuleiro)

        for i in tabuleiro:
            if 0 not in i:
                print("PARABÉNS! VOCE COMPLETOU O JOGO SUDOKU. FINALIZANDO O PROGRAMA...")
                time.sleep(1)
                exit(1)
