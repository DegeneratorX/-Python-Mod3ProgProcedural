def substituicao_letras(tabuleiro, linha_vazia, cont_tabuleiro_j, cont_grade):
    cont_tabuleiro_i = 0
    for elemento in linha_vazia:
        if elemento in "abcdefghi":
            if tabuleiro[cont_tabuleiro_j][cont_tabuleiro_i] == 0:
                linha_vazia[cont_grade] = " "
            else:
                linha_vazia[cont_grade] = tabuleiro[cont_tabuleiro_j][cont_tabuleiro_i]
            cont_tabuleiro_i =+ 1
            cont_grade =+ 2
    linha_vazia = " ".join(linha_vazia)
    return linha_vazia


def desenho_grade(tabuleiro):
    letras_grade = "    A   B   C    D   E   F    G   H   I    "
    linha_fina_grade = " ++---+---+---++---+---+---++---+---+---++ "
    linha_grossa_grade = " ++===+===+===++===+===+===++===+===+===++ "
    linha_vazia = [  ["1||", "a", "|", "b", "|", "c", "||", "d", "|", "e" ,"|", "f", "||", "g", "|", "h" ,"|", "i", "||1"],
                     ["2||", "a", "|", "b", "|", "c", "||", "d", "|", "e" ,"|", "f", "||", "g", "|", "h" ,"|", "i", "||2"],
                     ["3||", "a", "|", "b", "|", "c", "||", "d", "|", "e" ,"|", "f", "||", "g", "|", "h" ,"|", "i", "||3"],
                     ["4||", "a", "|", "b", "|", "c", "||", "d", "|", "e" ,"|", "f", "||", "g", "|", "h" ,"|", "i", "||4"],
                     ["5||", "a", "|", "b", "|", "c", "||", "d", "|", "e" ,"|", "f", "||", "g", "|", "h" ,"|", "i", "||5"],
                     ["6||", "a", "|", "b", "|", "c", "||", "d", "|", "e" ,"|", "f", "||", "g", "|", "h" ,"|", "i", "||6"],
                     ["7||", "a", "|", "b", "|", "c", "||", "d", "|", "e" ,"|", "f", "||", "g", "|", "h" ,"|", "i", "||7"],
                     ["8||", "a", "|", "b", "|", "c", "||", "d", "|", "e" ,"|", "f", "||", "g", "|", "h" ,"|", "i", "||8"],
                     ["9||", "a", "|", "b", "|", "c", "||", "d", "|", "e" ,"|", "f", "||", "g", "|", "h" ,"|", "i", "||9"]]

    print(letras_grade)
    print(linha_fina_grade)

    conti_tab = 0
    contj_tab = 0
    conti_grade = 1
    contj_grade = 0
    coluna = 0

    for j in linha_vazia:
        for i in j:
            if i in "abcdefghi" and conti_tab < 9:
                if tabuleiro[contj_tab][conti_tab] == 0:
                    linha_vazia[contj_grade][conti_grade] = " "
                else:
                    linha_vazia[contj_grade][conti_grade] = tabuleiro[contj_tab][conti_tab]
                conti_tab = conti_tab + 1
                conti_grade = conti_grade + 2
        contj_tab = contj_tab + 1
        contj_grade = contj_grade + 1
        conti_grade = 1
        conti_tab = 0
        print(" ".join(j))
        coluna = coluna + 1
        if coluna == 3 or coluna == 6:
            print(linha_grossa_grade)
        else:
            print(linha_fina_grade)

    print(letras_grade)

