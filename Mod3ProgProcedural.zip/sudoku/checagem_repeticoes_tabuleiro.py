def percorrer_quadrantes(quadrante, entrada_convertido_indices, tabuleiro):
    minj = None
    maxj = None
    mini = None
    maxi = None
    if quadrante == 1:
        minj = 0
        maxj = 3
        mini = 0
        maxi = 3
    elif quadrante == 2:
        minj = 0
        maxj = 3
        mini = 3
        maxi = 6
    elif quadrante == 3:
        minj = 0
        maxj = 3
        mini = 6
        maxi = 9
    elif quadrante == 4:
        minj = 3
        maxj = 6
        mini = 0
        maxi = 3
    elif quadrante == 5:
        minj = 3
        maxj = 6
        mini = 3
        maxi = 6
    elif quadrante == 6:
        minj = 3
        maxj = 6
        mini = 6
        maxi = 9
    elif quadrante == 7:
        minj = 6
        maxj = 9
        mini = 0
        maxi = 3
    elif quadrante == 8:
        minj = 6
        maxj = 9
        mini = 3
        maxi = 6
    elif quadrante == 9:
        minj = 6
        maxj = 9
        mini = 6
        maxi = 9
    #print(f"minj = {minj}, maxj = {maxj}, mini = {mini}, maxi = {maxi}")
    for j in range(minj, maxj):
        for i in range(mini, maxi):
            if entrada_convertido_indices[2] == tabuleiro[j][i]:
                print(F"O quadrante {quadrante} já tem um valor '{entrada_convertido_indices[2]}' inserido!")
                return True
    return False


def repeticoes_quadrante_entrada(entrada_convertido_indices, tabuleiro):
    if 0 <= entrada_convertido_indices[0] <= 2 and 0 <= entrada_convertido_indices[1] <= 2:
        quadrante = 1
        return percorrer_quadrantes(quadrante, entrada_convertido_indices, tabuleiro)
    elif 3 <= entrada_convertido_indices[0] <= 5 and 0 <= entrada_convertido_indices[1] <= 2:
        quadrante = 2
        return percorrer_quadrantes(quadrante, entrada_convertido_indices, tabuleiro)
    elif 6 <= entrada_convertido_indices[0] <= 8 and 0 <= entrada_convertido_indices[1] <= 2:
        quadrante = 3
        return percorrer_quadrantes(quadrante, entrada_convertido_indices, tabuleiro)
    elif 0 <= entrada_convertido_indices[0] <= 2 and 3 <= entrada_convertido_indices[1] <= 5:
        quadrante = 4
        return percorrer_quadrantes(quadrante, entrada_convertido_indices, tabuleiro)
    elif 3 <= entrada_convertido_indices[0] <= 5 and 3 <= entrada_convertido_indices[1] <= 5:
        quadrante = 5
        return percorrer_quadrantes(quadrante, entrada_convertido_indices, tabuleiro)
    elif 6 <= entrada_convertido_indices[0] <= 8 and 3 <= entrada_convertido_indices[1] <= 5:
        quadrante = 6
        return percorrer_quadrantes(quadrante, entrada_convertido_indices, tabuleiro)
    elif 0 <= entrada_convertido_indices[0] <= 2 and 6 <= entrada_convertido_indices[1] <= 8:
        quadrante = 7
        return percorrer_quadrantes(quadrante, entrada_convertido_indices, tabuleiro)
    elif 3 <= entrada_convertido_indices[0] <= 5 and 6 <= entrada_convertido_indices[1] <= 8:
        quadrante = 8
        return percorrer_quadrantes(quadrante, entrada_convertido_indices, tabuleiro)
    elif 6 <= entrada_convertido_indices[0] <= 8 and 6 <= entrada_convertido_indices[1] <= 8:
        quadrante = 9
        return percorrer_quadrantes(quadrante, entrada_convertido_indices, tabuleiro)


#########################################


def repeticoes_linha_coluna(entrada_convertida_indices, tabuleiro):
    for j in range(9):  # Verifica valores horizontais
        if entrada_convertida_indices[1] == j:
            for valor in tabuleiro[j]:
                if valor == entrada_convertida_indices[2]:
                    print(f"A linha passada já possui o valor {entrada_convertida_indices[2]}!")
                    return True

    tabuleiro_transposto = [
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0],
    ]

    for i in range(9):  # Transpostando a matriz pra verificar repetições em colunas
        for j in range(9):
            tabuleiro_transposto[i][j] = tabuleiro[j][i]
    print()
    #print("TABULEIRO TRANSPOSTO!:")
    #for i in tabuleiro_transposto:
    #    print(i)
    print()

    for j in range(9):  # Verifico repetições em colunas
        if entrada_convertida_indices[0] == j:
            for valor in tabuleiro_transposto[j]:
                if valor == entrada_convertida_indices[2]:
                    print(f"A coluna passada já possui o valor {entrada_convertida_indices[2]}!")
                    return True
    return False
